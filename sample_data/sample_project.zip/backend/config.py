# Application Configuration
# Vulnerability: Hardcoded OpenAI and Database Credentials
OPENAI_API_KEY = "sk-live-9876543210abcdef9876543210abcdef"
DATABASE_URL = "postgres://dbuser:supersecretpass123@db.internal:5432/proddb"
PORT = 8080
