import subprocess
import requests
from flask import Flask, request

app = Flask(__name__)

@app.route('/run')
def run_command():
    cmd = request.args.get('cmd')
    # Vulnerability: Subprocess with shell=True
    res = subprocess.run(f'echo {cmd}', shell=True, capture_output=True)
    return res.stdout

@app.route('/compute')
def compute():
    expr = request.args.get('expr')
    # Vulnerability: Unsafe eval
    val = eval(expr)
    return str(val)

@app.route('/fetch')
def fetch():
    target = request.args.get('target')
    # Vulnerability: verify=False
    resp = requests.get(target, verify=False)
    return resp.text

if __name__ == '__main__':
    # Vulnerability: debug=True
    app.run(debug=True, host='0.0.0.0', port=5000)
